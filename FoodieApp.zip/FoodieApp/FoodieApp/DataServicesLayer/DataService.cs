﻿

using FoodieApp.DTO;
using FoodieApp.Models;
using Microsoft.EntityFrameworkCore;

public class DataService
{
    private readonly  FoodieDbContext context;
    public DataService(FoodieDbContext _context)
    { 
        context = _context;
    }
    public RestLocDTO GetRestaurantWithLocation(int restaurantId)
    {
        var restaurant = context.Restaurants
            .FirstOrDefault(r => r.RestaurantId == restaurantId);

        if (restaurant == null)
            return null;

        var location = context.Locations
            .FirstOrDefault(l => l.LocationId == restaurant.RestLocId);

        return new RestLocDTO
        {
            Restaurant = restaurant,
            Location = location
        };
    }
    public List<FoodItem> GetFoodItemsByRestaurant(int restaurantId)
    {
        return context.FoodItems
            .Where(f => f.RestaurantId == restaurantId)
            .ToList();
    }


}
