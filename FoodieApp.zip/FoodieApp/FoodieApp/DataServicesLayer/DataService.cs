﻿

using FoodieApp.Models;

public class DataService
{
    private readonly  FoodieDbContext context;
    public DataService(FoodieDbContext _context)
    { 
        context = _context;
    }
   
}
