﻿using FoodieApp.DTO;
using FoodieApp.Models;
using Microsoft.EntityFrameworkCore;
using static FoodieApp.DTO.OrderDetailsDTO;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace FoodieApp.DBAccess
{
    public class DbAccess
    {


        private readonly FoodieDbContext context;

        public DbAccess(FoodieDbContext dbContext)
        {
            context = dbContext;
        }

        // Create new user and return created UserDTO
        public bool AddUser(UserDTO data)
        {
            var user = new User
            {
                FirstName = data.firstName,
                LastName = data.lastName,
                Email = data.email,
                PhoneNumber = data.phoneNumber,
                UserRole = data.userRole,
                Password = data.password
            };

            context.Users.Add(user);
            context.SaveChanges();

            return true;
        }

        // Get all users as a list of UserDTO
        public List<UserDTO> GetAllUsers()
        {
            return context.Users
                .Select(u => new UserDTO
                {
                    userId = u.UserId,
                    firstName = u.FirstName,
                    lastName = u.LastName,
                    email = u.Email,
                    phoneNumber = u.PhoneNumber,
                    password = u.Password,
                    userRole = u.UserRole
                })
                .ToList();

        }

        // Get a single user by id, return UserDTO or null if not found
        public UserDTO GetUserById(int id)
        {
            var user = context.Users.Find(id);
            if (user == null) return null;

            return new UserDTO
            {
                userId = user.UserId,
                firstName = user.FirstName,
                lastName = user.LastName,
                email = user.Email,
                phoneNumber = user.PhoneNumber,
                password = user.Password,
                userRole = user.UserRole
            };
        }

        // Update user by id, return true if success, false if not found
        public bool UpdateUser(int id, UserDTO data)
        {
            var user = context.Users.Find(id);
            if (user == null) return false;

            user.FirstName = data.firstName;
            user.LastName = data.lastName;
            user.Email = data.email;
            user.PhoneNumber = data.phoneNumber;
            user.Password = user.Password;

            user.UserRole = data.userRole;

            context.SaveChanges();
            return true;
        }

        // Delete user by id, return true if success, false if not found
        public bool DeleteUser(int id)
        {
            var user = context.Users.Find(id);
            if (user == null) return false;

            context.Users.Remove(user);
            context.SaveChanges();
            return true;
        }
        //------Restaurant------------------------------------


        public bool AddRestaurant(RestaurantDTO data, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (!context.Locations.Any(l => l.LocationId == data.RestLocId))
            {
                errorMessage = "Location not found";
                return false;
            }

            var rest = new Restaurant
            {
                RestaurantName = data.RestaurantName,
                RestaurantAddress = data.RestaurantAddress,
                Likes = data.Likes,
                Rating = data.Rating,
                OpeningTime = data.OpeningTime,
                CloseTime = data.CloseTime,
                RestLocId = data.RestLocId
            };

            context.Restaurants.Add(rest);
            context.SaveChanges();

            return true;
        }

        public List<RestaurantDTO> GetAllRestaurants()
        {
            return context.Restaurants.Select(r => new RestaurantDTO
            {
                RestaurantId = r.RestaurantId,
                RestaurantName = r.RestaurantName,
                RestaurantAddress = r.RestaurantAddress,
                Likes = r.Likes,
                Rating = r.Rating,
                OpeningTime = r.OpeningTime,
                CloseTime = r.CloseTime,
                RestLocId = r.RestLocId
            }).ToList();
        }

        public RestaurantDTO GetRestaurantById(int id)
        {
            var r = context.Restaurants.Find(id);
            if (r == null) return null;

            return new RestaurantDTO
            {
                RestaurantId = r.RestaurantId,
                RestaurantName = r.RestaurantName,
                RestaurantAddress = r.RestaurantAddress,
                Likes = r.Likes,
                Rating = r.Rating,
                OpeningTime = r.OpeningTime,
                CloseTime = r.CloseTime,
                RestLocId = r.RestLocId
            };
        }

        public bool UpdateRestaurant(int id, RestaurantDTO data)
        {
            var r = context.Restaurants.Find(id);
            if (r == null) return false;

            r.RestaurantName = data.RestaurantName;
            r.RestaurantAddress = data.RestaurantAddress;
            r.Likes = data.Likes;
            r.Rating = data.Rating;
            r.OpeningTime = data.OpeningTime;
            r.CloseTime = data.CloseTime;
            r.RestLocId = data.RestLocId;

            context.SaveChanges();
            return true;
        }

        public bool DeleteRestaurant(int id)
        {
            var r = context.Restaurants.Find(id);
            if (r == null) return false;

            context.Restaurants.Remove(r);
            context.SaveChanges();
            return true;
        }

        //-----------------------------Locations----------------------------

        public bool AddLocation(LocationDTO data)
        {
            var existingLocation = context.Locations
       .FirstOrDefault(l => l.City == data.City && l.Area == data.Area);

            if (existingLocation != null)
            {
                // Location exists, return false or throw exception or handle accordingly
                return false;
            }

            var location = new Location
            {
                City = data.City,
                Area = data.Area,
                PostalCode = data.PostalCode
            };

            context.Locations.Add(location);
            context.SaveChanges();
            return true;
        }

        // Get all Locations
        public List<LocationDTO> GetAllLocations()
        {
            return context.Locations.Select(l => new LocationDTO
            {
                LocationId = l.LocationId,
                City = l.City,
                Area = l.Area,
                PostalCode = l.PostalCode
            }).ToList();
        }

        // Get Location by ID
        public LocationDTO GetLocationById(int id)
        {
            var loc = context.Locations.Find(id);
            if (loc == null) return null;

            return new LocationDTO
            {
                LocationId = loc.LocationId,
                City = loc.City,
                Area = loc.Area,
                PostalCode = loc.PostalCode
            };
        }

        // Update Location
        public bool UpdateLocation(int id, LocationDTO data)
        {
            var loc = context.Locations.Find(id);
            if (loc == null) return false;

            loc.City = data.City;
            loc.Area = data.Area;
            loc.PostalCode = data.PostalCode;

            context.SaveChanges();
            return true;
        }

        // Delete Location
        public bool DeleteLocation(int id)
        {
            var loc = context.Locations.Find(id);
            if (loc == null) return false;

            context.Locations.Remove(loc);
            context.SaveChanges();
            return true;
        }
        ///------------------------------------Address--------------------------
        public bool AddAddress(AddressDTO data)
        {
            var address = new Address
            {
                Street = data.Street,
                City = data.City,
                PostalCode = data.PostalCode,
                UserId = data.UserId
            };
            context.Addressesss.Add(address);
            context.SaveChanges();
            return true;
        }

        // Update Address by UserId (update first matching address)
        public bool UpdateAddressByUserId(int userId, AddressDTO data)
        {
            var address = context.Addressesss.FirstOrDefault(a => a.UserId == userId);
            if (address == null)
                return false;

            address.Street = data.Street;
            address.City = data.City;
            address.PostalCode = data.PostalCode;

            context.SaveChanges();
            return true;
        }

        // Get all addresses
        public List<AddressDTO> GetAllAddresses()
        {
            return context.Addressesss.Select(a => new AddressDTO
            {
                AddressId = a.AddressId,
                Street = a.Street,
                City = a.City,
                PostalCode = a.PostalCode,
                UserId = a.UserId
            }).ToList();
        }

        // Get address by UserId
        public AddressDTO GetAddressByUserId(int userId)
        {
            var address = context.Addressesss.FirstOrDefault(a => a.UserId == userId);
            if (address == null) return null;

            return new AddressDTO
            {
                AddressId = address.AddressId,
                Street = address.Street,
                City = address.City,
                PostalCode = address.PostalCode,
                UserId = address.UserId
            };
        }

        // Delete Address by AddressId
        public bool DeleteAddress(int addressId)
        {
            var address = context.Addressesss.Find(addressId);
            if (address == null)
                return false;

            context.Addressesss.Remove(address);
            context.SaveChanges();
            return true;
        }


        //--------------------------------Order------------------------------------------

        //public OrderDTO AddOrder(OrderDTO data)
        //{
        //    var order = new Order
        //    {
        //        OrderDate = data.OrderDate,
        //        OrderTotal = data.OrderTotal,
        //        Discount = data.Discount,
        //        gst = data.gst,
        //        FinalAmount = data.FinalAmount,
        //        OrderStatus = data.OrderStatus,
        //        deliveredBy = data.deliveredBy,
        //        UserId = data.UserId,
        //        AddressId = data.AddressId,
        //        RestId = data.RestId,
        //        ScheduleDeliveryAt = data.ScheduleDeliveryAt,
        //        orderLineItems = data.orderLineItems?.Select(oli => new OrderLineItem
        //        {
        //            FoodItemId = oli.FoodItemId,
        //            Quantity = oli.Quantity
        //        }).ToList()
        //    };

        //    context.Orders.Add(order);
        //    context.SaveChanges();

        //    data.OrderId = order.OrderId;
        //    return data;
        //}

        //public OrderDTO GetOrderById(int id)
        //{
        //    var order = context.Orders
        //        .Include(o => o.orderLineItems)
        //        .FirstOrDefault(o => o.OrderId == id);
        //    if (order == null) return null;

        //    return new OrderDTO
        //    {
        //        OrderId = order.OrderId,
        //        OrderDate = order.OrderDate,
        //        OrderTotal = order.OrderTotal,
        //        Discount = order.Discount,
        //        gst = order.gst,
        //        FinalAmount = order.FinalAmount,
        //        OrderStatus = order.OrderStatus,
        //        deliveredBy = order.deliveredBy,
        //        UserId = order.UserId,
        //        AddressId = order.AddressId,
        //        RestId = order.RestId,
        //        ScheduleDeliveryAt = order.ScheduleDeliveryAt,
        //        orderLineItems = order.orderLineItems.Select(oli => new OrderLineItemDTO
        //        {
        //            OrderItemId = oli.OrderItemId,
        //            OrderId = oli.OrderId,
        //            FoodItemId = oli.FoodItemId,
        //            Quantity = oli.Quantity
        //        }).ToList()
        //    };
        //}

        //public bool UpdateOrder(OrderDTO orderDto)
        //{
        //    var existingOrder = context.Orders
        //        .Include(o => o.orderLineItems)
        //        .FirstOrDefault(o => o.OrderId == orderDto.OrderId);

        //    if (existingOrder == null)
        //        return false;

        //    existingOrder.OrderDate = orderDto.OrderDate;
        //    existingOrder.OrderTotal = orderDto.OrderTotal;
        //    existingOrder.Discount = orderDto.Discount;
        //    existingOrder.gst = orderDto.gst;
        //    existingOrder.FinalAmount = orderDto.FinalAmount;
        //    existingOrder.OrderStatus = orderDto.OrderStatus;
        //    existingOrder.deliveredBy = orderDto.deliveredBy;
        //    existingOrder.UserId = orderDto.UserId;
        //    existingOrder.AddressId = orderDto.AddressId;
        //    existingOrder.RestId = orderDto.RestId;
        //    existingOrder.ScheduleDeliveryAt = orderDto.ScheduleDeliveryAt;

        //    // Optional: Update OrderLineItems (complex, add or remove as needed)
        //    // For simplicity, skipping orderLineItems update here

        //    context.SaveChanges();
        //    return true;
        //}

        //// Delete order by ID
        //public bool DeleteOrder(int id)
        //{
        //    var order = context.Orders.FirstOrDefault(o => o.OrderId == id);
        //    if (order == null)
        //        return false;

        //    context.Orders.Remove(order);
        //    context.SaveChanges();
        //    return true;
        //}



        ////------------------------------OrderLineItem---------------------

        //public List<OrderLineItemDTO> GetAllOrderLineItems()
        //{
        //    return context.OrderLines
        //        .Select(oli => new OrderLineItemDTO
        //        {
        //            OrderItemId = oli.OrderItemId,
        //            OrderId = oli.OrderId,
        //            FoodItemId = oli.FoodItemId,
        //            Quantity = oli.Quantity
        //        }).ToList();
        //}

        //// Get OrderLineItem by ID
        //public OrderLineItemDTO GetOrderLineItemById(int id)
        //{
        //    var oli = context.OrderLines
        //        .FirstOrDefault(o => o.OrderItemId == id);
        //    if (oli == null) return null;

        //    return new OrderLineItemDTO
        //    {
        //        OrderItemId = oli.OrderItemId,
        //        OrderId = oli.OrderId,
        //        FoodItemId = oli.FoodItemId,
        //        Quantity = oli.Quantity
        //    };
        //}

        //// Add new OrderLineItem
        //public OrderLineItemDTO AddOrderLineItem(OrderLineItemDTO dto)
        //{
        //    var oli = new OrderLineItem
        //    {
        //        OrderId = dto.OrderId,
        //        FoodItemId = dto.FoodItemId,
        //        Quantity = dto.Quantity
        //    };

        //    context.OrderLines.Add(oli);
        //    context.SaveChanges();

        //    dto.OrderItemId = oli.OrderItemId;
        //    return dto;
        //}

        //// Update existing OrderLineItem
        //public bool UpdateOrderLineItem(OrderLineItemDTO dto)
        //{
        //    var existing = context.OrderLines
        //        .FirstOrDefault(o => o.OrderItemId == dto.OrderItemId);
        //    if (existing == null) return false;

        //    existing.OrderId = dto.OrderId;
        //    existing.FoodItemId = dto.FoodItemId;
        //    existing.Quantity = dto.Quantity;

        //    context.SaveChanges();
        //    return true;
        //}

        //// Delete OrderLineItem by ID
        //public bool DeleteOrderLineItem(int id)
        //{
        //    var oli = context.OrderLines.FirstOrDefault(o => o.OrderItemId == id);
        //    if (oli == null) return false;

        //    context.OrderLines.Remove(oli);
        //    context.SaveChanges();
        //    return true;
        //}

        ////-----------------------------------FoodItem-----------------------
        //public List<FoodItemDTO> GetAllFoodItems()
        //{
        //    return context.FoodItems
        //        .Include(f => f.Reviews)
        //        .Include(f => f.OrderLine)
        //        .Select(fi => new FoodItemDTO
        //        {
        //            FoodItemId = fi.FoodItemId,
        //            Name = fi.Name,
        //            Description = fi.Description,
        //            Price = fi.Price,
        //            RestaurantId = fi.RestaurantId,
        //            Reviews = fi.Reviews.Select(r => new ReviewDTO
        //            {
        //                ReviewId = r.ReviewId,
        //                Rating = r.Rating,
        //                CreatedAt = r.CreatedAt,
        //                Comments = r.Comments,
        //                UserId = r.UserId,
        //                OrderId = r.OrderId,
        //                FoodItemId = r.FoodItemId
        //            }).ToList(),
        //            OrderLine = fi.OrderLine.Select(ol => new OrderLineItemDTO
        //            {
        //                OrderItemId = ol.OrderItemId,
        //                OrderId = ol.OrderId,
        //                FoodItemId = ol.FoodItemId,
        //                Quantity = ol.Quantity
        //            }).ToList()
        //        }).ToList();
        //}

        //// Get by ID
        //public FoodItemDTO GetFoodItemById(int id)
        //{
        //    var fi = context.FoodItems
        //        .Include(f => f.Reviews)
        //        .Include(f => f.OrderLine)
        //        .FirstOrDefault(f => f.FoodItemId == id);

        //    if (fi == null) return null;

        //    return new FoodItemDTO
        //    {
        //        FoodItemId = fi.FoodItemId,
        //        Name = fi.Name,
        //        Description = fi.Description,
        //        Price = fi.Price,
        //        RestaurantId = fi.RestaurantId,
        //        Reviews = fi.Reviews.Select(r => new ReviewDTO
        //        {
        //            ReviewId = r.ReviewId,
        //            Rating = r.Rating,
        //            CreatedAt = r.CreatedAt,
        //            Comments = r.Comments,
        //            UserId = r.UserId,
        //            OrderId = r.OrderId,
        //            FoodItemId = r.FoodItemId
        //        }).ToList(),
        //        OrderLine = fi.OrderLine.Select(ol => new OrderLineItemDTO
        //        {
        //            OrderItemId = ol.OrderItemId,
        //            OrderId = ol.OrderId,
        //            FoodItemId = ol.FoodItemId,
        //            Quantity = ol.Quantity
        //        }).ToList()
        //    };
        //}

        //// Add FoodItem
        //public FoodItemDTO AddFoodItem(FoodItemDTO dto)
        //{
        //    var fi = new FoodItem
        //    {
        //        Name = dto.Name,
        //        Description = dto.Description,
        //        Price = dto.Price,
        //        RestaurantId = dto.RestaurantId
        //    };

        //    context.FoodItems.Add(fi);
        //    context.SaveChanges();

        //    dto.FoodItemId = fi.FoodItemId;
        //    return dto;
        //}

        //// Update FoodItem
        //public bool UpdateFoodItem(FoodItemDTO dto)
        //{
        //    var existing = context.FoodItems.FirstOrDefault(f => f.FoodItemId == dto.FoodItemId);
        //    if (existing == null) return false;

        //    existing.Name = dto.Name;
        //    existing.Description = dto.Description;
        //    existing.Price = dto.Price;
        //    existing.RestaurantId = dto.RestaurantId;

        //    context.SaveChanges();
        //    return true;
        //}

        //// Delete FoodItem
        //public bool DeleteFoodItem(int id)
        //{
        //    var fi = context.FoodItems.FirstOrDefault(f => f.FoodItemId == id);
        //    if (fi == null) return false;

        //    context.FoodItems.Remove(fi);
        //    context.SaveChanges();
        //    return true;
        //}


        // Add or update order with nested orderlineitems and fooditems
        public bool AddOrUpdateOrderWithDetails(OrderDetailsDTO data)
        {
            var existingOrder = context.Orders
                .Include(o => o.orderLineItems)
                .FirstOrDefault(o => o.OrderId == data.Order.OrderId);

            if (existingOrder == null)
            {
                // Add new order
                var newOrder = new Order
                {
                    OrderDate = data.Order.OrderDate,
                    OrderTotal = data.Order.OrderTotal,
                    Discount = data.Order.Discount,
                    gst = data.Order.gst,
                    FinalAmount = data.Order.FinalAmount,
                    OrderStatus = data.Order.OrderStatus,
                    deliveredBy = data.Order.deliveredBy,
                    UserId = data.Order.UserId,
                    AddressId = data.Order.AddressId,
                    RestId = data.Order.RestId,
                    ScheduleDeliveryAt = data.Order.ScheduleDeliveryAt,
                    orderLineItems = new List<OrderLineItem>()
                };

                // Add order line items
                foreach (var lineItemDto in data.OrderLineItems)
                {
                    newOrder.orderLineItems.Add(new OrderLineItem
                    {
                        FoodItemId = lineItemDto.FoodItemId,
                        Quantity = lineItemDto.Quantity
                    });
                }

                // Add food items - assuming these are new or updated food items
                foreach (var foodDto in data.FoodItems)
                {
                    var existingFood = context.FoodItems
                        .FirstOrDefault(f => f.FoodItemId == foodDto.FoodItemId);

                    if (existingFood == null)
                    {
                        context.FoodItems.Add(new FoodItem
                        {
                            Name = foodDto.Name,
                            Description = foodDto.Description,
                            Price = foodDto.Price,
                            RestaurantId = foodDto.RestaurantId
                        });
                    }
                    else
                    {
                        existingFood.Name = foodDto.Name;
                        existingFood.Description = foodDto.Description;
                        existingFood.Price = foodDto.Price;
                        existingFood.RestaurantId = foodDto.RestaurantId;
                    }
                }

                context.Orders.Add(newOrder);
            }
            else
            {
                // Update existing order
                existingOrder.OrderDate = data.Order.OrderDate;
                existingOrder.OrderTotal = data.Order.OrderTotal;
                existingOrder.Discount = data.Order.Discount;
                existingOrder.gst = data.Order.gst;
                existingOrder.FinalAmount = data.Order.FinalAmount;
                existingOrder.OrderStatus = data.Order.OrderStatus;
                existingOrder.deliveredBy = data.Order.deliveredBy;
                existingOrder.UserId = data.Order.UserId;
                existingOrder.AddressId = data.Order.AddressId;
                existingOrder.RestId = data.Order.RestId;
                existingOrder.ScheduleDeliveryAt = data.Order.ScheduleDeliveryAt;

                // Update order line items: remove old, add new
                context.OrderLines.RemoveRange(existingOrder.orderLineItems);
                existingOrder.orderLineItems.Clear();

                foreach (var lineItemDto in data.OrderLineItems)
                {
                    existingOrder.orderLineItems.Add(new OrderLineItem
                    {
                        FoodItemId = lineItemDto.FoodItemId,
                        Quantity = lineItemDto.Quantity
                    });
                }

                // Update food items as above
                foreach (var foodDto in data.FoodItems)
                {
                    var existingFood = context.FoodItems
                        .FirstOrDefault(f => f.FoodItemId == foodDto.FoodItemId);

                    if (existingFood == null)
                    {
                        context.FoodItems.Add(new FoodItem
                        {
                            Name = foodDto.Name,
                            Description = foodDto.Description,
                            Price = foodDto.Price,
                            RestaurantId = foodDto.RestaurantId
                        });
                    }
                    else
                    {
                        existingFood.Name = foodDto.Name;
                        existingFood.Description = foodDto.Description;
                        existingFood.Price = foodDto.Price;
                        existingFood.RestaurantId = foodDto.RestaurantId;
                    }
                }
            }

            context.SaveChanges();
            return true;
        }

        // Get order with details
        public OrderDetailsDTO GetOrderWithDetails(int orderId)
        {
            var order = context.Orders
                .Include(o => o.orderLineItems)
                .FirstOrDefault(o => o.OrderId == orderId);

            if (order == null) return null;

            var orderLineItemsDto = order.orderLineItems.Select(oli => new OrderLineItemDTO
            {
                OrderItemId = oli.OrderItemId,
                //OrderId = oli.OrderId,
                FoodItemId = oli.FoodItemId,
                Quantity = oli.Quantity
            }).ToList();

            // Assuming you want to include all related food items in DTO
            var foodItemsDto = new List<FoodItemDTO>();
            foreach (var oli in order.orderLineItems)
            {
                var food = context.FoodItems.Find(oli.FoodItemId);
                if (food != null)
                {
                    foodItemsDto.Add(new FoodItemDTO
                    {
                        FoodItemId = food.FoodItemId,
                        Name = food.Name,
                        Description = food.Description,
                        Price = food.Price,
                        RestaurantId = food.RestaurantId
                    });
                }
            }

            return new OrderDetailsDTO
            {
                Order = new OrderDTO
                {
                    OrderId = order.OrderId,
                    OrderDate = order.OrderDate,
                    OrderTotal = order.OrderTotal,
                    Discount = order.Discount,
                    gst = order.gst,
                    FinalAmount = order.FinalAmount,
                    OrderStatus = order.OrderStatus,
                    deliveredBy = order.deliveredBy,
                    UserId = order.UserId,
                    AddressId = order.AddressId,
                    RestId = order.RestId,
                    ScheduleDeliveryAt = order.ScheduleDeliveryAt
                },
                OrderLineItems = orderLineItemsDto,
                FoodItems = foodItemsDto
            };
        }

        // Delete order with related order line items
        public bool DeleteOrder(int orderId)
        {
            var order = context.Orders
                .Include(o => o.orderLineItems)
                .FirstOrDefault(o => o.OrderId == orderId);

            if (order == null) return false;

            context.OrderLines.RemoveRange(order.orderLineItems);
            context.Orders.Remove(order);
            context.SaveChanges();

            return true;
        }
    

        //---------------------------------------Review----------------------------------------
        public List<ReviewDTO> GetAllReviews()
        {
            return context.Reviews
                .Select(r => new ReviewDTO
                {
                    ReviewId = r.ReviewId,
                    Rating = r.Rating,
                    CreatedAt = r.CreatedAt,
                    Comments = r.Comments,
                    UserId = r.UserId,
                    OrderId = r.OrderId,
                    FoodItemId = r.FoodItemId
                }).ToList();
        }

        // Get review by id
        public ReviewDTO GetReviewById(int id)
        {
            var r = context.Reviews.FirstOrDefault(x => x.ReviewId == id);
            if (r == null) return null;

            return new ReviewDTO
            {
                ReviewId = r.ReviewId,
                Rating = r.Rating,
                CreatedAt = r.CreatedAt,
                Comments = r.Comments,
                UserId = r.UserId,
                OrderId = r.OrderId,
                FoodItemId = r.FoodItemId
            };
        }

        // Add review
        public ReviewDTO AddReview(ReviewDTO dto)
        {
            var r = new Review
            {
                Rating = dto.Rating,
                CreatedAt = dto.CreatedAt == default ? DateTime.UtcNow : dto.CreatedAt,
                Comments = dto.Comments,
                UserId = dto.UserId,
                OrderId = dto.OrderId,
                FoodItemId = dto.FoodItemId
            };

            context.Reviews.Add(r);
            context.SaveChanges();

            dto.ReviewId = r.ReviewId;
            dto.CreatedAt = r.CreatedAt;
            return dto;
        }

        // Update review
        public bool UpdateReview(ReviewDTO dto)
        {
            var existing = context.Reviews.FirstOrDefault(r => r.ReviewId == dto.ReviewId);
            if (existing == null) return false;

            existing.Rating = dto.Rating;
            existing.Comments = dto.Comments;
            existing.UserId = dto.UserId;
            existing.OrderId = dto.OrderId;
            existing.FoodItemId = dto.FoodItemId;
            // CreatedAt usually not updated

            context.SaveChanges();
            return true;
        }

        // Delete review
        public bool DeleteReview(int id)
        {
            var r = context.Reviews.FirstOrDefault(r => r.ReviewId == id);
            if (r == null) return false;

            context.Reviews.Remove(r);
            context.SaveChanges();
            return true;
        }

        //---------------------------------Payment----------------------------------
        public List<PaymentDTO> GetAllPayments()
        {
            return context.Payments.Select(p => new PaymentDTO
            {
                PaymentId = p.PaymentId,
                PaymentMethod = p.PaymentMethod,
                Amount = p.Amount,
                PaymentStatus = p.PaymentStatus,
                OrderId = p.OrderId
            }).ToList();
        }

        // Get payment by id
        public PaymentDTO GetPaymentById(int id)
        {
            var p = context.Payments.FirstOrDefault(x => x.PaymentId == id);
            if (p == null) return null;

            return new PaymentDTO
            {
                PaymentId = p.PaymentId,
                PaymentMethod = p.PaymentMethod,
                Amount = p.Amount,
                PaymentStatus = p.PaymentStatus,
                OrderId = p.OrderId
            };
        }

        // Add payment
        public PaymentDTO AddPayment(PaymentDTO dto)
        {
            var p = new Payment
            {
                PaymentMethod = dto.PaymentMethod,
                Amount = dto.Amount,
                PaymentStatus = dto.PaymentStatus,
                OrderId = dto.OrderId
            };

            context.Payments.Add(p);
            context.SaveChanges();

            dto.PaymentId = p.PaymentId;
            return dto;
        }

        // Update payment
        public bool UpdatePayment(PaymentDTO dto)
        {
            var existing = context.Payments.FirstOrDefault(p => p.PaymentId == dto.PaymentId);
            if (existing == null) return false;

            existing.PaymentMethod = dto.PaymentMethod;
            existing.Amount = dto.Amount;
            existing.PaymentStatus = dto.PaymentStatus;
            existing.OrderId = dto.OrderId;

            context.SaveChanges();
            return true;
        }

        // Delete payment
        public bool DeletePayment(int id)
        {
            var p = context.Payments.FirstOrDefault(p => p.PaymentId == id);
            if (p == null) return false;

            context.Payments.Remove(p);
            context.SaveChanges();
            return true;
        }
    }
}






