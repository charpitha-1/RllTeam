﻿using FoodieApp.DTO;
using FoodieApp.Models;
using Microsoft.EntityFrameworkCore;



namespace FoodieApp.DBAccess
{
    public class DbAccess
    {


        private readonly FoodieDbContext context;

        public DbAccess(FoodieDbContext dbContext)
        {
            context = dbContext;
        }

        // Create new user and return created UserDTO
        public bool AddUser(UserDTO data)
        {
            var user = new User
            {
                FirstName = data.firstName,
                LastName = data.lastName,
                Email = data.email,
                PhoneNumber = data.phoneNumber,
                UserRole = data.userRole,
                Password = data.password
            };

            context.Users.Add(user);
            context.SaveChanges();

            return true;
        }

        // Get all users as a list of UserDTO
        public List<UserDTO> GetAllUsers()
        {
            return context.Users
                .Select(u => new UserDTO
                {
                    userId = u.UserId,
                    firstName = u.FirstName,
                    lastName = u.LastName,
                    email = u.Email,
                    phoneNumber = u.PhoneNumber,
                    password = u.Password,
                    userRole = u.UserRole
                })
                .ToList();

        }

        // Get a single user by id, return UserDTO or null if not found
        public UserDTO GetUserById(int id)
        {
            var user = context.Users.Find(id);
            if (user == null) return null;

            return new UserDTO
            {
                userId = user.UserId,
                firstName = user.FirstName,
                lastName = user.LastName,
                email = user.Email,
                phoneNumber = user.PhoneNumber,
                password = user.Password,
                userRole = user.UserRole
            };
        }

        // Update user by id, return true if success, false if not found
        public bool UpdateUser(int id, UserDTO data)
        {
            var user = context.Users.Find(id);
            if (user == null) return false;

            user.FirstName = data.firstName;
            user.LastName = data.lastName;
            user.Email = data.email;
            user.PhoneNumber = data.phoneNumber;
            user.Password = user.Password;

            user.UserRole = data.userRole;

            context.SaveChanges();
            return true;
        }

        // Delete user by id, return true if success, false if not found
        public bool DeleteUser(int id)
        {
            var user = context.Users.Find(id);
            if (user == null) return false;

            context.Users.Remove(user);
            context.SaveChanges();
            return true;
        }
        //------Restaurant------------------------------------


        public bool AddRestaurant(RestaurantDTO data, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (!context.Locations.Any(l => l.LocationId == data.RestLocId))
            {
                errorMessage = "Location not found";
                return false;
            }

            var rest = new Restaurant
            {
                RestaurantName = data.RestaurantName,
                RestaurantAddress = data.RestaurantAddress,
                Likes = data.Likes,
                Rating = data.Rating,
                OpeningTime = data.OpeningTime,
                CloseTime = data.CloseTime,
                RestLocId = data.RestLocId
            };

            context.Restaurants.Add(rest);
            context.SaveChanges();

            return true;
        }

        public List<RestaurantDTO> GetAllRestaurants()
        {
            return context.Restaurants.Select(r => new RestaurantDTO
            {
                RestaurantId = r.RestaurantId,
                RestaurantName = r.RestaurantName,
                RestaurantAddress = r.RestaurantAddress,
                Likes = r.Likes,
                Rating = r.Rating,
                OpeningTime = r.OpeningTime,
                CloseTime = r.CloseTime,
                RestLocId = r.RestLocId
            }).ToList();
        }

        public RestaurantDTO GetRestaurantById(int id)
        {
            var r = context.Restaurants.Find(id);
            if (r == null) return null;

            return new RestaurantDTO
            {
                RestaurantId = r.RestaurantId,
                RestaurantName = r.RestaurantName,
                RestaurantAddress = r.RestaurantAddress,
                Likes = r.Likes,
                Rating = r.Rating,
                OpeningTime = r.OpeningTime,
                CloseTime = r.CloseTime,
                RestLocId = r.RestLocId
            };
        }

        public bool UpdateRestaurant(int id, RestaurantDTO data)
        {
            var r = context.Restaurants.Find(id);
            if (r == null) return false;

            r.RestaurantName = data.RestaurantName;
            r.RestaurantAddress = data.RestaurantAddress;
            r.Likes = data.Likes;
            r.Rating = data.Rating;
            r.OpeningTime = data.OpeningTime;
            r.CloseTime = data.CloseTime;
            r.RestLocId = data.RestLocId;

            context.SaveChanges();
            return true;
        }

        public bool DeleteRestaurant(int id)
        {
            var r = context.Restaurants.Find(id);
            if (r == null) return false;

            context.Restaurants.Remove(r);
            context.SaveChanges();
            return true;
        }

        //-----------------------------Locations----------------------------

        public bool AddLocation(LocationDTO data)
        {
            var existingLocation = context.Locations
       .FirstOrDefault(l => l.City == data.City && l.Area == data.Area);

            if (existingLocation != null)
            {
                // Location exists, return false or throw exception or handle accordingly
                return false;
            }

            var location = new Location
            {
                City = data.City,
                Area = data.Area,
                PostalCode = data.PostalCode
            };

            context.Locations.Add(location);
            context.SaveChanges();
            return true;
        }

        // Get all Locations
        public List<LocationDTO> GetAllLocations()
        {
            return context.Locations.Select(l => new LocationDTO
            {
                LocationId = l.LocationId,
                City = l.City,
                Area = l.Area,
                PostalCode = l.PostalCode
            }).ToList();
        }

        // Get Location by ID
        public LocationDTO GetLocationById(int id)
        {
            var loc = context.Locations.Find(id);
            if (loc == null) return null;

            return new LocationDTO
            {
                LocationId = loc.LocationId,
                City = loc.City,
                Area = loc.Area,
                PostalCode = loc.PostalCode
            };
        }

        // Update Location
        public bool UpdateLocation(int id, LocationDTO data)
        {
            var loc = context.Locations.Find(id);
            if (loc == null) return false;

            loc.City = data.City;
            loc.Area = data.Area;
            loc.PostalCode = data.PostalCode;

            context.SaveChanges();
            return true;
        }

        // Delete Location
        public bool DeleteLocation(int id)
        {
            var loc = context.Locations.Find(id);
            if (loc == null) return false;

            context.Locations.Remove(loc);
            context.SaveChanges();
            return true;
        }
        ///------------------------------------Address--------------------------
        public bool AddAddress(AddressDTO data)
        {
            var address = new Address
            {
                Street = data.Street,
                City = data.City,
                PostalCode = data.PostalCode,
                UserId = data.UserId
            };
            context.Addressesss.Add(address);
            context.SaveChanges();
            return true;
        }

        // Update Address by UserId (update first matching address)
        public bool UpdateAddressByUserId(int userId, AddressDTO data)
        {
            var address = context.Addressesss.FirstOrDefault(a => a.UserId == userId);
            if (address == null)
                return false;

            address.Street = data.Street;
            address.City = data.City;
            address.PostalCode = data.PostalCode;

            context.SaveChanges();
            return true;
        }

        // Get all addresses
        public List<AddressDTO> GetAllAddresses()
        {
            return context.Addressesss.Select(a => new AddressDTO
            {
                AddressId = a.AddressId,
                Street = a.Street,
                City = a.City,
                PostalCode = a.PostalCode,
                UserId = a.UserId
            }).ToList();
        }

        // Get address by UserId
        public AddressDTO GetAddressByUserId(int userId)
        {
            var address = context.Addressesss.FirstOrDefault(a => a.UserId == userId);
            if (address == null) return null;

            return new AddressDTO
            {
                AddressId = address.AddressId,
                Street = address.Street,
                City = address.City,
                PostalCode = address.PostalCode,
                UserId = address.UserId
            };
        }

        // Delete Address by AddressId
        public bool DeleteAddress(int addressId)
        {
            var address = context.Addressesss.Find(addressId);
            if (address == null)
                return false;

            context.Addressesss.Remove(address);
            context.SaveChanges();
            return true;
        }

        //------
        public FoodItem AddFoodItem(FoodItem foodItem)
        {
            context.FoodItems.Add(foodItem);
            context.SaveChanges();
            return foodItem;
        }
        public List<FoodItem> GetFoodItemsByRestaurant(int restaurantId)
        {
            return context.FoodItems
                .Where(f => f.RestaurantId == restaurantId)
                .ToList();
        }

        public FoodItem GetFoodItem(int restaurantId, int foodItemId)
        {
            return context.FoodItems
                .FirstOrDefault(f => f.RestaurantId == restaurantId && f.FoodItemId == foodItemId);
        }


        public bool UpdateFoodItem(FoodItem updatedItem)
        {
            var existing = context.FoodItems
                .FirstOrDefault(f => f.FoodItemId == updatedItem.FoodItemId && f.RestaurantId == updatedItem.RestaurantId);

            if (existing == null)
                return false;

            existing.Name = updatedItem.Name;
            existing.Description = updatedItem.Description;
            existing.Price = updatedItem.Price;

            context.SaveChanges();

            return true;
        }


        public bool DeleteFoodItem(int restaurantId, int foodItemId)
        {
            var existing = context.FoodItems
                .FirstOrDefault(f => f.RestaurantId == restaurantId && f.FoodItemId == foodItemId);

            if (existing == null)
                return false;

            context.FoodItems.Remove(existing);
            context.SaveChanges();
            return true;
        }

        //---------------------------------------Review-------------------------------------
        public ReviewDTO GetReviewById(int id)
        {
            var review = context.Reviews.Find(id);
            if (review == null) return null;

            return new ReviewDTO
            {
                ReviewId = review.ReviewId,
                Rating = review.Rating,
                CreatedAt = review.CreatedAt,
                Comments = review.Comments,
                UserId = review.UserId,
                OrderId = review.OrderId,
                FoodItemId = review.FoodItemId
            };
        }


        public ReviewDTO AddReview(ReviewDTO dto)
        {
            var entity = new Review
            {
                Rating = dto.Rating,
                CreatedAt = dto.CreatedAt == default ? DateTime.UtcNow : dto.CreatedAt,
                Comments = dto.Comments,
                UserId = dto.UserId,
                OrderId = dto.OrderId,
                FoodItemId = dto.FoodItemId
            };

            context.Reviews.Add(entity);
            context.SaveChanges();

            dto.ReviewId = entity.ReviewId;  // update DTO with generated ID
            dto.CreatedAt = entity.CreatedAt; // ensure CreatedAt is set

            return dto;
        }
        //-------------------------OrderDetails------------------------
        public bool AddOrder(OrderDetailsDTO order)
        {
            if (order == null || order.OrderLineItems == null || !order.OrderLineItems.Any())
                return false;

            double orderTotal = 0;

            Order ord = new Order
            {
                OrderDate = order.OrderDate,
                Discount = order.Discount,
                gst = order.Gst,
                OrderStatus = order.OrderStatus,
                deliveredBy = order.DeliveredBy,
                UserId = order.UserId,
                AddressId = order.AddressId,
                RestId = order.RestId,
                ScheduleDeliveryAt = order.ScheduleDeliveryAt,
                orderLineItems = new List<OrderLineItem>() // ✅ Initialize the list
            };

            foreach (var lidto in order.OrderLineItems)
            {
                double subtotal = lidto.Qty * lidto.UnitPrice;
                orderTotal += subtotal;

                var lineItem = new OrderLineItem
                {
                    Quantity = lidto.Qty,
                    FoodItemId = lidto.FoodItemId
                };

                ord.orderLineItems.Add(lineItem);
            }

            ord.OrderTotal = orderTotal;
            ord.FinalAmount = orderTotal - ord.Discount + ord.gst;

            context.Orders.Add(ord);
            context.SaveChanges();

            return true;
        }
        public OrderDetailsDTO GetOrder(int orderId)
        {
            var order = context.Orders
                .Include(o => o.orderLineItems)
                .FirstOrDefault(o => o.OrderId == orderId);

            if (order == null) return null;

            return new OrderDetailsDTO
            {
                OrderId = order.OrderId,
                OrderDate = order.OrderDate,
                Discount = order.Discount,
                Gst = order.gst,
                FinalAmount = order.FinalAmount,
                OrderStatus = order.OrderStatus,
                DeliveredBy = order.deliveredBy,
                UserId = order.UserId,
                AddressId = order.AddressId,
                RestId = order.RestId,
                ScheduleDeliveryAt = order.ScheduleDeliveryAt,
                OrderTotal = order.OrderTotal,
                OrderLineItems = order.orderLineItems.Select(oli => new OrderLineItemDTO
                {
                    FoodItemId = oli.FoodItemId,
                    Qty = oli.Quantity,
                    UnitPrice = 0 // Set if you track price per item in orderLineItems or FoodItem entity
                }).ToList()
            };
        }
        //public OrderDetailsDTO AddOrder(OrderDetailsDTO dto)
        //{
        //    var order = new Order
        //    {
        //        OrderDate = dto.OrderDate,
        //        Discount = dto.Discount,
        //        gst = dto.Gst,
        //        FinalAmount = dto.FinalAmount,
        //        OrderStatus = dto.OrderStatus,
        //        deliveredBy = dto.DeliveredBy,
        //        UserId = dto.UserId,
        //        AddressId = dto.AddressId,
        //        RestId = dto.RestId,
        //        ScheduleDeliveryAt = dto.ScheduleDeliveryAt,
        //        OrderTotal = dto.OrderTotal,
        //        orderLineItems = dto.OrderLineItems.Select(oliDto => new OrderLineItem
        //        {
        //            FoodItemId = oliDto.FoodItemId,
        //            Quantity = oliDto.Qty
        //            // UnitPrice can be stored if model has it
        //        }).ToList()
        //    };

        //    context.Orders.Add(order);
        //    context.SaveChanges();

        //    dto.OrderId = order.OrderId;  // assign generated OrderId back to DTO
        //    return dto;
        //}





        public bool UpdateOrder(OrderDetailsDTO dto)
        {
            var existingOrder = context.Orders
                .Include(o => o.orderLineItems)
                .FirstOrDefault(o => o.OrderId == dto.OrderId);

            if (existingOrder == null) return false;

            // Update order properties
            existingOrder.OrderDate = dto.OrderDate;
            existingOrder.Discount = dto.Discount;
            existingOrder.gst = dto.Gst;
            existingOrder.FinalAmount = dto.FinalAmount;
            existingOrder.OrderStatus = dto.OrderStatus;
            existingOrder.deliveredBy = dto.DeliveredBy;
            existingOrder.UserId = dto.UserId;
            existingOrder.AddressId = dto.AddressId;
            existingOrder.RestId = dto.RestId;
            existingOrder.ScheduleDeliveryAt = dto.ScheduleDeliveryAt;
            existingOrder.OrderTotal = dto.OrderTotal;

            // Update order line items:
            // For simplicity, clear existing and add new from dto
            context.OrderLines.RemoveRange(existingOrder.orderLineItems);

            existingOrder.orderLineItems = dto.OrderLineItems.Select(oliDto => new OrderLineItem
            {
                FoodItemId = oliDto.FoodItemId,
                Quantity = oliDto.Qty
            }).ToList();

            context.SaveChanges();
            return true;

        }


       
    }
}



