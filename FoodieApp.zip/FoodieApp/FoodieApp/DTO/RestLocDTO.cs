﻿namespace FoodieApp.DTO
{
    public class RestLocDTO
    {
            public RestaurantDTO Restaurant { get; set; }
            public LocationDTO Location { get; set; }
        public FoodItemDTO FoodItem { get; set; }
    }
}
