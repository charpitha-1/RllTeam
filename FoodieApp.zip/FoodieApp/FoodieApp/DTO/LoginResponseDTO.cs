﻿namespace FoodieApp.DTO
{
    public class LoginResponseDTO
    {
        public string Email { get; set; }
        public string UserRole { get; set; }
    }
}
