﻿//using FoodieApp.DBAccess;
//using FoodieApp.DTO;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace FoodieApp.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class PaymentController : ControllerBase
//    {
//        private readonly DbAccess dbAccess;

//        public PaymentController(DbAccess db)
//        {
//            dbAccess = db;
//        }

//        [HttpGet]
//        public IActionResult GetAll()
//        {
//            var payments = dbAccess.GetAllPayments();
//            return Ok(payments);
//        }

//        [HttpGet("{id}")]
//        public IActionResult GetById(int id)
//        {
//            var payment = dbAccess.GetPaymentById(id);
//            if (payment == null)
//                return NotFound(new { result = false, message = "Payment not found" });

//            return Ok(payment);
//        }

//        [HttpPost]
//        public IActionResult Add([FromBody] PaymentDTO dto)
//        {
//            if (!ModelState.IsValid)
//                return BadRequest(ModelState);

//            var added = dbAccess.AddPayment(dto);
//            return Ok(new { result = true, message = "Payment added successfully", payment = added });
//        }

//        [HttpPut("{id}")]
//        public IActionResult Update(int id, [FromBody] PaymentDTO dto)
//        {
//            if (id != dto.PaymentId)
//                return BadRequest(new { result = false, message = "ID mismatch" });

//            var updated = dbAccess.UpdatePayment(dto);
//            if (!updated)
//                return NotFound(new { result = false, message = "Payment not found" });

//            return Ok(new { result = true, message = "Payment updated successfully" });
//        }

//        [HttpDelete("{id}")]
//        public IActionResult Delete(int id)
//        {
//            var deleted = dbAccess.DeletePayment(id);
//            if (!deleted)
//                return NotFound(new { result = false, message = "Payment not found" });

//            return Ok(new { result = true, message = "Payment deleted successfully" });
//        }
//    }
//}

