﻿using FoodieApp.DBAccess;
using FoodieApp.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FoodieApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private readonly DbAccess dbAccess;

        public LocationController(DbAccess db)
        {
            dbAccess = db;
        }

        [HttpPost]
        public IActionResult AddLocation(LocationDTO data)
        {
            bool added = dbAccess.AddLocation(data);
            if (!added)
            {
                return Conflict(new { result = "Location with the same city and area already exists." });
            }

            return Ok(new { result = "Location added successfully" });
        }

        [HttpGet]
        public IActionResult GetAllLocations()
        {
            var locations = dbAccess.GetAllLocations();
            return Ok(new { result = locations });
        }

        [HttpGet("{id}")]
        public IActionResult GetLocation(int id)
        {
            var location = dbAccess.GetLocationById(id);
            if (location == null)
                return NotFound(new { result = false, message = "Location not found" });

            return Ok(new { result = true, location });
        }

        [HttpPut("{id}")]
        public IActionResult UpdateLocation(int id, LocationDTO data)
        {
            bool status = dbAccess.UpdateLocation(id, data);
            if (!status)
                return NotFound(new { result = false, message = "Location not found" });

            return Ok(new { result = "Location updated successfully" });
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteLocation(int id)
        {
            bool status = dbAccess.DeleteLocation(id);
            if (!status)
                return NotFound(new { result = false, message = "Location not found" });

            return Ok(new { result = "Location deleted successfully" });
        }
    }
}

