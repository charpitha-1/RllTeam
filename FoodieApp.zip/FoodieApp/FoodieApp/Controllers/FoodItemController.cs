﻿using FoodieApp.DBAccess;
using FoodieApp.DTO;
using FoodieApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace FoodieApp.Controllers
{
    //[Route("api/FoodItemRestaurant/{RestaurantId}/FoodItem")]
    [Route("api/[controller]")]
    [ApiController]
    public class FoodItemController : ControllerBase
    {
        private readonly DbAccess dbAccess;

        public FoodItemController(DbAccess db)
        {
            dbAccess = db;
       
        }

        // GET all fooditems for restaurant
        [HttpGet("{restaurantId}")]
        public IActionResult GetAll(int restaurantId)
        {
            var foodItems = dbAccess.GetFoodItemsByRestaurant(restaurantId);

            var dtos = foodItems.Select(f => new FoodItemDTO
            {
                FoodItemId = f.FoodItemId,
                Name = f.Name,
                Description = f.Description,
                Price = f.Price,
                RestaurantId = f.RestaurantId
            }).ToList();

            return Ok(dtos);
        }

        // GET single fooditem by id
        [HttpGet("{restaurantId}/{foodItemId}")]
        public IActionResult Get(int restaurantId, int foodItemId)
        {
            var foodItem = dbAccess.GetFoodItem(restaurantId, foodItemId);

            if (foodItem == null)
                return NotFound($"FoodItem {foodItemId} not found for Restaurant {restaurantId}");

            var dto = new FoodItemDTO
            {
                FoodItemId = foodItem.FoodItemId,
                Name = foodItem.Name,
                Description = foodItem.Description,
                Price = foodItem.Price,
                RestaurantId = foodItem.RestaurantId
            };

            return Ok(dto);
        }

        // POST create new fooditem in restaurant
        [HttpPost("{RestId}")]
        public IActionResult Create(int RestId, FoodItemDTO newDto)
        {
            if (newDto == null)
                return BadRequest();

            
            var entity = new FoodItem
            {
                Name = newDto.Name,
                Description = newDto.Description,
                Price = newDto.Price,
                RestaurantId = RestId
            };

            var added = dbAccess.AddFoodItem(entity);

            newDto.FoodItemId = added.FoodItemId;

            return CreatedAtAction(nameof(Get),
                new { restaurantId = RestId, foodItemId = newDto.FoodItemId },
                newDto);
        }

        // PUT update existing fooditem

        [HttpPut("{restaurantId}/{foodItemId}")]
        public IActionResult UpdateFoodItem(int restaurantId, int foodItemId,FoodItemDTO foodItemDto)
        {
            //if (foodItemDto == null)
            //    return BadRequest("No data received");

            //if (foodItemId != foodItemDto.FoodItemId || restaurantId != foodItemDto.RestaurantId)
            //    return BadRequest("Route IDs and body IDs do not match");

            var updatedEntity = new FoodItem
            {
                FoodItemId = foodItemId,
                Name = foodItemDto.Name,
                Description = foodItemDto.Description,
                Price = foodItemDto.Price,
                RestaurantId = restaurantId
            };

            bool updated = dbAccess.UpdateFoodItem(updatedEntity);

            if (!updated)
                return NotFound($"FoodItem {foodItemId} not found for Restaurant {restaurantId}");

            return Ok(new { message = $"FoodItem {foodItemId} Updated successfully." });
        }

        // DELETE fooditem
        [HttpDelete("{restaurantId}/{foodItemId}")]
        public IActionResult Delete(int restaurantId, int foodItemId)
        {
            bool deleted = dbAccess.DeleteFoodItem(restaurantId, foodItemId);

            if (!deleted)
                return NotFound();

            return Ok(new { message = $"FoodItem {foodItemId} deleted successfully." });
        }
    }
}
