﻿using FoodieApp.DBAccess;
using FoodieApp.DTO;
using FoodieApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static FoodieApp.DTO.OrderDetailsDTO;

namespace FoodieApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderDetailsController : ControllerBase
    {
        private readonly DbAccess dbAccess;

        public OrderDetailsController(DbAccess db)
        {
            dbAccess = db;

        }
        [HttpGet("{orderId}")]
        public IActionResult GetOrder(int orderId)
        {
            var order = dbAccess.GetOrder(orderId);
            if (order == null) return NotFound();
            return Ok(order);
        }

        //[HttpPost]
        //public IActionResult CreateOrder(OrderDetailsDTO orderDto)
        //{
        //    if (orderDto == null) return BadRequest();

        //    var createdOrder = dbAccess.AddOrder(orderDto);
        //    if (createdOrder == null) return BadRequest("Unable to create order");

        //    return CreatedAtAction(nameof(GetOrder), new { orderId = createdOrder.OrderId }, createdOrder);
        //}
        [HttpPut("{orderId}")]
        public IActionResult UpdateOrder(int orderId, OrderDetailsDTO orderDto)
        {
            if (orderDto == null || orderId != orderDto.OrderId)
                return BadRequest();

            bool updated = dbAccess.UpdateOrder(orderDto);
            if (!updated) return NotFound();

            return NoContent();
        }

    }
}

