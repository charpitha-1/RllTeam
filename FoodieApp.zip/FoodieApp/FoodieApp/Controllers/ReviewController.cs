﻿using FoodieApp.DBAccess;
using FoodieApp.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodieApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly DbAccess dbAccess;

        public ReviewController(DbAccess db)
        {
            dbAccess = db;
        }



      
        //[HttpPost]
        //public IActionResult Create([FromBody] ReviewDTO dto)
        //{
        //    if (dto == null)
        //        return BadRequest();

        //    var review = dbAccess.AddReview(dto);
        //    return CreatedAtAction(nameof(Get), new { reviewId = review.ReviewId }, review);
        //}



        //[HttpPost]
        //public IActionResult CreateReview( ReviewDTO review)
        //{
        //    dbAccess.Create(review);
        //    return CreatedAtAction(nameof(GetReviewById), new { id = review.ReviewId }, review);
        //}

        //[HttpGet("{id}")]
        //public IActionResult GetById(int id)
        //{
        //    var review = dbAccess.GetReviewById(id);
        //    if (review == null)
        //        return NotFound(new { result = false, message = "Review not found" });

        //    return Ok(review);
        //}

        //[HttpPost]
        //public IActionResult Add([FromBody] ReviewDTO dto)
        //{
        //    if (!ModelState.IsValid)
        //        return BadRequest(ModelState);

        //    var added = dbAccess.AddReview(dto);
        //    return Ok(new { result = true, message = "Review added successfully", review = added });
        //}

        //[HttpPut("{id}")]
        //public IActionResult Update(int id, [FromBody] ReviewDTO dto)
        //{
        //    if (id != dto.ReviewId)
        //        return BadRequest(new { result = false, message = "ID mismatch" });

        //    var updated = dbAccess.UpdateReview(dto);
        //    if (!updated)
        //        return NotFound(new { result = false, message = "Review not found" });

        //    return Ok(new { result = true, message = "Review updated successfully" });
        //}

        //[HttpDelete("{id}")]
        //public IActionResult Delete(int id)
        //{
        //    var deleted = dbAccess.DeleteReview(id);
        //    if (!deleted)
        //        return NotFound(new { result = false, message = "Review not found" });

        //    return Ok(new { result = true, message = "Review deleted successfully" });
        //}
    }
}

