﻿namespace FoodieApp.Models;
    using Microsoft.EntityFrameworkCore;

    public class FoodieDbContext:DbContext
    {
        public FoodieDbContext(DbContextOptions<FoodieDbContext> options):base(options) { }
        public DbSet<Location> Locations { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Address> Addressesss { get; set; }
        public DbSet<Restaurant> Restaurants { get; set; }
    
        public DbSet<Order> Orders { get; set; }
        public DbSet<Payment> Payments { get; set; }
       public DbSet<OrderLineItem> OrderLines { get; set; }
       public DbSet<FoodItem> FoodItems { get; set; }
       public DbSet<Review> Reviews { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Location>().HasIndex(l => new
        {
            l.City,
            l.Area
        }).IsUnique();
        modelBuilder.Entity<Order>()
        .HasOne(o => o.User)
        .WithMany(u => u.Orders)
        .HasForeignKey(o => o.UserId).OnDelete(DeleteBehavior.NoAction);
        modelBuilder.Entity<Order>()
        .HasOne(o => o.Restaurant)
        .WithMany(r => r.Orders)
        .HasForeignKey(o => o.RestId).OnDelete(DeleteBehavior.NoAction); ;
        modelBuilder.Entity<Order>()
    .HasOne(o => o.Address)
    .WithMany(a => a.Orders)
    .HasForeignKey(o => o.AddressId);


        ;
    }

}

