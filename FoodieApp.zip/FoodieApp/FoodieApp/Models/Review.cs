﻿using FoodieApp.Models;
using System.ComponentModel.DataAnnotations;

public class Review
{
    [Key]
    public int ReviewId { get; set; }

    public int? Rating { get; set; }

    [Required]
    public DateTime CreatedAt { get; set; }

    public string Comments { get; set; }

   
    public int UserId { get; set; }
    public User Users { get; set; }

   
    public int OrderId { get; set; }
    public Order Order { get; set; }

   
    public int FoodItemId { get; set; }
    public FoodItem FoodItem { get; set; }
}
