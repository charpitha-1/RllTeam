﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodieApp.Models
{
    public class Location
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int LocationId { get; set; }
       
        public string City { get; set; }
        public string Area { get; set; }
        public string PostalCode { get; set; }
        //public List<Address> addresses { get; set; }
        public List<Restaurant> restaurants { get; set; }
        //public List<Driver> drivers { get; set; }

    }
}
