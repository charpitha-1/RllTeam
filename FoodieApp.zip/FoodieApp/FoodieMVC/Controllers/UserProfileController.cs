﻿using FoodieApp.DBAccess;
using FoodieApp.Models;
using FoodieMVC.DTO;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace FoodieMVC.Controllers
{
    public class UserProfileController : Controller
    {
        private readonly DbAccess dbaccess;
        private readonly FoodieDbContext context;
        public UserProfileController(DbAccess _dbaccess,FoodieDbContext _context)
        {
            context = _context;
            dbaccess = _dbaccess;
        }
        [HttpGet]
        public async Task<IActionResult> ViewProfileAsync()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7059");
            HttpResponseMessage msg = await client.GetAsync("Users");
            msg.EnsureSuccessStatusCode();
            string RespString = await msg.Content.ReadAsStringAsync();
            var list = JsonSerializer.Deserialize<UserProfileDTO>(RespString);
            return View(list);


            //List<UserProfileDTO> users = context.Users
            //    .Select(u => new UserProfileDTO
            //    {

            //        userId = u.UserId,
            //        firstName = u.FirstName,
            //        lastName = u.LastName,
            //        email = u.Email,
            //        password=u.Password,
            //        phoneNumber = u.PhoneNumber,
            //        userRole=u.UserRole,

            //    })
            //    .ToList();

            //return View(users);
        }

    }
}

