﻿
using FoodieMVC.DTO;
using FoodieMVC.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace FoodieMVC.Controllers
{
    public class UserProfileController : Controller
    {
        
        private readonly ClientHelper clientHelper;
        public UserProfileController(ClientHelper client)
        {
            clientHelper = client;
           
        }
        [HttpGet]
        public async Task<IActionResult> ViewProfile()
        {

            var res = await clientHelper.GetData<GetUserListDTO>("User");
            return View(res.result);
        }
        [Route("ViewUser/{id}")]
        [HttpGet]
            public async Task<IActionResult> ViewUser(int id)
        {
            var res = await clientHelper.GetData<GetUserDTO>($"User/{id}");
            var user = res?.result;

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

    }
}

