﻿using Microsoft.AspNetCore.Mvc;

namespace FoodieMVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Welcome()
        {
            return View();
        }
    }
}
