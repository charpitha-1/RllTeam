﻿using FoodieApp.Models;
using FoodieMVC.DTO;
using FoodieMVC.Infra;
using Microsoft.AspNetCore.Mvc;

public class SearchController : Controller
{
    private readonly ClientHelper clientHelper;
    public SearchController(ClientHelper client)
    {
        clientHelper = client;
    }
    [HttpGet]
    public async Task<IActionResult> SearchFood()
    {

        var res = await clientHelper.GetData<GetLocationDTO>("Location");
        var r = await clientHelper.GetData<GetLocationDTO>("Restaurant");
        var fooditems= await clientHelper.GetData<GetLocationDTO>("Restaurant");

        return View(res.result);
    }

}
