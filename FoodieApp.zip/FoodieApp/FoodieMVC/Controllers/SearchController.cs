﻿using FoodieApp.Models;
using FoodieMVC.DTO;
using Microsoft.AspNetCore.Mvc;

public class SearchController : Controller
{
   

   

}
