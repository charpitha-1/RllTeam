﻿using FoodieApp.Models;
using FoodieMVC.DTO;
using FoodieMVC.Infra;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using System.Text.Json;

public class SearchController : Controller
{
    private readonly HttpClient client;

    public SearchController(IHttpClientFactory factory)
    {
        client = factory.CreateClient();
    }
    //[HttpGet]
    //public async Task<IActionResult> SearchFood()
    //{

    //    var res = await clientHelper.GetData<GetLocationDTO>("Location");
    //    var r = await clientHelper.GetData<GetLocationDTO>("Restaurant");
    //    var fooditems= await clientHelper.GetData<GetLocationDTO>("Restaurant");

    //    return View(res.result);
    //}
    [HttpGet]
    public async Task<IActionResult> PopularFoods()
    {


        // 1. Get orders
        var ordersResponse = await client.GetStringAsync("https://localhost:44377/api/OrderDetails");
        var ordersWrapped = JsonSerializer.Deserialize<ApiResponse<OrderDetailsDTO>>(ordersResponse);
        var orders = ordersWrapped?.result ?? new List<OrderDetailsDTO>();

        // 2. Get food items
        var foodsResponse = await client.GetStringAsync("https://localhost:44377/api/FoodItem");
        var foodsWrapped = JsonSerializer.Deserialize<ApiResponse<FoodItemDTO>>(foodsResponse);
        var foods = foodsWrapped?.result ?? new List<FoodItemDTO>();

        // 3. Get Rest items
        var restResponse = await client.GetStringAsync("https://localhost:44377/api/Restaurant");
        var restWrapped = JsonSerializer.Deserialize<ApiResponse<RestuarantDTO>>(foodsResponse);
        var restaurants = restWrapped?.result ?? new List<RestuarantDTO>();


        
        var FlattenPopularFoodIds = orders.SelectMany(o => o.orderLineItems).ToList();
        var tempRes = (from fpl in FlattenPopularFoodIds
                       join fd in foods on fpl.foodItemId equals fd.foodItemId
                       join rest in restaurants on fd.restaurantId equals rest.restaurantId
                       select new { fname = fd.name, fid = fd.foodItemId, rid = rest.restaurantId, rname = rest.restaurantName, totqty = fpl.qty }
                        ).ToList();


        var FinalResult = tempRes.GroupBy(g => new { g.fname, g.rname }).Select(itm => new { foodName = itm.Key.fname, restname = itm.Key.rname, Item = itm }).ToList().Take(5);
        var PopualarDishes = FinalResult.Select(f =>
        new PopularFood()
        {
            FoodName = f.foodName,
            QuantityOrdered = f.Item.Sum(s => s.totqty)
        }).ToList();
   
        return View(PopualarDishes);
    }
    public async Task<IActionResult> DiscountedOrders()
    {
        var ordersResponse = await client.GetStringAsync("https://localhost:44377/api/OrderDetails");
        var ordersWrapped = JsonSerializer.Deserialize<ApiResponse<OrderDetailsDTO>>(ordersResponse);
        var orders = ordersWrapped?.result ?? new List<OrderDetailsDTO>();

        var foodsResponse = await client.GetStringAsync("https://localhost:44377/api/FoodItem");
        var foodsWrapped = JsonSerializer.Deserialize<ApiResponse<FoodItemDTO>>(foodsResponse);
        var foods = foodsWrapped?.result ?? new List<FoodItemDTO>();
        // Step 1: Group orders by user
        var groupedByUser = orders
            .GroupBy(o => o.userId)
            .ToDictionary(g => g.Key, g => g.OrderBy(o => o.orderDate).ToList());
        foreach (var order in orders)
        {
            // Join orderLineItems with foods on FoodItemId
            var lineItemsWithPrice = from lineItem in order.orderLineItems
                                     join food in foods on lineItem.foodItemId equals food.foodItemId
                                     select new
                                     {
                                         LineItem = lineItem,
                                         UnitPrice = food.price
                                     };

            foreach (var item in lineItemsWithPrice)
            {
                item.LineItem.unitPrice = (double)item.UnitPrice;
            }
        }

        // Step 2: Apply discounts
        foreach (var userGroup in groupedByUser)
        {
            
            var userOrders = userGroup.Value;
            
            for (int i = 0; i < userOrders.Count; i++)
            {
                
                var order = userOrders[i];
               
                order.orderTotal = order.orderLineItems.Sum(x => x.qty *x.unitPrice);

                if (i == 0) // First order
                {
                    order.discount = Math.Min(50, order.orderTotal * 0.10);
                }
                else // Regular user
                {
                    order.discount = order.orderTotal * 0.5;
                }

                order.gst = (order.orderTotal - order.discount) * 0.18;
                //delivery charges 
                order.deliveryCharge = order.distanceInKm <= 3 ? 20 : order.distanceInKm * 30;
                order.finalAmount = order.orderTotal - order.discount + order.gst;
            }
        }

        var processedOrders = groupedByUser.SelectMany(g => g.Value).ToList();

        return View(processedOrders);
    }
}
