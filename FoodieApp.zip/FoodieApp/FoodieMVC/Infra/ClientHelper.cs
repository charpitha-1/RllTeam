﻿using FoodieMVC.DTO;
using System.Text.Json;

namespace FoodieMVC.Infra
{
    public class ClientHelper
    { 
        private readonly HttpClient _httpClient;
        public ClientHelper(HttpClient client,IConfiguration cfg)
        {
               _httpClient = client;
           string BaseAdress= cfg.GetValue<string>("ApiData:url");
            _httpClient.BaseAddress = new Uri(BaseAdress);
        }

        public async Task<T> GetData<T>(string crtName)
        {
            HttpResponseMessage msg = await _httpClient.GetAsync(crtName);
            msg.EnsureSuccessStatusCode();
            string RespString = await msg.Content.ReadAsStringAsync();
            T list = JsonSerializer.Deserialize<T>(RespString);
            return list;

        }
    }
}
