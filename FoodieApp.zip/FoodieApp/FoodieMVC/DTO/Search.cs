﻿// DTO for displaying food items

// ViewModel for search filters + results
using FoodieMVC.DTO;

public class Search
{
   public  GetLocationDTO getLocation {  get; set; }

}
