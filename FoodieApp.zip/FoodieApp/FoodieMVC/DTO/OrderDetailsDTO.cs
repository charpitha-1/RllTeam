﻿using System.ComponentModel.DataAnnotations.Schema;

namespace FoodieMVC.DTO
{
    public class OrderDetailsDTO
    {
        public int orderId { get; set; }
        public DateTime orderDate { get; set; }
        public double orderTotal { get; set; } = 10;
        public double discount { get; set; } = 0.5;
        public double gst { get; set; } = 0.2;
        public double finalAmount { get; set; }
        public string orderStatus { get; set; }
        public string deliveredBy { get; set; }
        [NotMapped]
        public double deliveryCharge { get; set; } = 20;
        [NotMapped]
        public double distanceInKm { get; set; } = 3;
        public int userId { get; set; }
        public int addressId { get; set; }
        public int restId { get; set; }
        public DateTime? scheduleDeliveryAt { get; set; }

        public List<OrderLineItemDTO> orderLineItems { get; set; }
    }
    public class GetOrderDetails
    {
        public List<OrderDetailsDTO> result { get; set; }
    }
}