﻿
namespace FoodieMVC.DTO
{
    public class FoodItemDTO
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string RestaurantName { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string Location { get; set; }
    }
    public class GetFoodItemDTO
    {
        public List<FoodItemDTO> result { get; set; }

        public static implicit operator GetFoodItemDTO(List<FoodItemDTO> v)
        {
            throw new NotImplementedException();
        }
    }
}
