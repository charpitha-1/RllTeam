﻿namespace FoodieApp.DTO
{
    public class ReviewDTO
    {
        public int ReviewId { get; set; }
        public int? Rating { get; set; }
        public DateTime CreatedAt { get; set; }
        public string Comments { get; set; }
        public int UserId { get; set; }
        public int OrderId { get; set; }
        public int FoodItemId { get; set; }
    }
}
