﻿namespace FoodieApp.DTO
{
    public class OrderDetailsDTO
    {
        public OrderDTO Order { get; set; }
        public List<OrderLineItemDTO> OrderLineItems { get; set; }
        public List<FoodItemDTO> FoodItems { get; set; }
        public class OrderDTO
        {
            public int OrderId { get; set; }
            public DateTime OrderDate { get; set; }
            public double OrderTotal { get; set; }
            public double Discount { get; set; }
            public double gst { get; set; }
            public double FinalAmount { get; set; }
            public string OrderStatus { get; set; }
            public string deliveredBy { get; set; }
            public int UserId { get; set; }
            public int AddressId { get; set; }
            public int RestId { get; set; }
            public DateTime? ScheduleDeliveryAt { get; set; }

            public List<OrderLineItemDTO> OrderLineItems { get; set; }
        }

        public class OrderLineItemDTO
        {
            public int OrderItemId { get; set; }
            public int FoodItemId { get; set; }
            public int Quantity { get; set; }

            public FoodItemDTO FoodItem { get; set; }
        }

        public class FoodItemDTO
        {
            public int FoodItemId { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public decimal Price { get; set; }
            public int RestaurantId { get; set; }
           
        }

    }
}
