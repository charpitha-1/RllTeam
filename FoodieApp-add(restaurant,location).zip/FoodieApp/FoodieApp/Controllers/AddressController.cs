﻿using FoodieApp.DBAccess;
using FoodieApp.DTO;
using FoodieApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FoodieApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {

        private readonly DbAccess dbAccess;

        public AddressController(DbAccess db)
        {
            dbAccess = db;
        }
        [HttpPost]
        public IActionResult AddAddress(AddressDTO data)
        {
            bool status = dbAccess.AddAddress(data);
            if (status)
                return Ok(new { result = "Address added successfully" });
            return BadRequest(new { result = "Failed to add address" });
        }

        // Update Address by UserId
        [HttpPut("{userId}")]
        public IActionResult UpdateAddress(int userId, AddressDTO data)
        {
            bool status = dbAccess.UpdateAddressByUserId(userId, data);
            if (!status)
                return NotFound(new { result = false, message = "Address not found for this user" });

            return Ok(new { result = "Address updated successfully" });
        }

        [HttpGet]
        public IActionResult GetAllAddresses()
        {
            var addresses = dbAccess.GetAllAddresses();
            return Ok(new { result = addresses });
        }

        // Get Address by UserId
        [HttpGet("{userId}")]
        public IActionResult GetAddressByUserId(int userId)
        {
            var address = dbAccess.GetAddressByUserId(userId);
            if (address == null)
                return NotFound(new { result = false, message = "Address not found for this user" });

            return Ok(new { result = true, address });
        }

        [HttpDelete("{AddressId}")]
        public IActionResult DeleteAddress(int addressId)
        {
            bool status = dbAccess.DeleteAddress(addressId);
            if (!status)
                return NotFound(new { result = false, message = "Address not found" });

            return Ok(new { result = "Address deleted successfully" });
        }
    }
}

