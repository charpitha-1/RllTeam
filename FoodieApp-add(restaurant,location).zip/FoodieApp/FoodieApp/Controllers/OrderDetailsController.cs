﻿using FoodieApp.DBAccess;
using FoodieApp.DTO;
using FoodieApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static FoodieApp.DTO.OrderDetailsDTO;

namespace FoodieApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderDetailsController : ControllerBase
    {
        private readonly FoodieDbContext _context;

        public OrderDetailsController(FoodieDbContext context)
        {
            _context = context;
        }
        [HttpPost("addorupdate")]
        public IActionResult AddOrUpdate( OrderDetailsDTO data)
        {
            if (data == null)
                return BadRequest(new { result = false, message = "Data is null" });

            using var transaction = _context.Database.BeginTransaction();
            try
            {
                // Upsert FoodItems
                foreach (var foodDto in data.FoodItems)
                {
                    var food = _context.FoodItems.FirstOrDefault(f => f.FoodItemId == foodDto.FoodItemId);
                    if (food == null)
                    {
                        food = new FoodItem
                        {
                            FoodItemId = foodDto.FoodItemId,
                            Name = foodDto.Name,
                            Description = foodDto.Description,
                            Price = foodDto.Price,
                            RestaurantId = foodDto.RestaurantId
                        };
                        _context.FoodItems.Add(food);
                    }
                    else
                    {
                        food.Name = foodDto.Name;
                        food.Description = foodDto.Description;
                        food.Price = foodDto.Price;
                        food.RestaurantId = foodDto.RestaurantId;
                        _context.FoodItems.Update(food);
                    }
                }
                _context.SaveChanges();

                // Upsert Order
                var order = _context.Orders
                    .Include(o => o.orderLineItems)
                    .FirstOrDefault(o => o.OrderId == data.Order.OrderId);

                if (order == null)
                {
                    order = new Order
                    {
                        OrderDate = data.Order.OrderDate,
                        OrderTotal = data.Order.OrderTotal,
                        Discount = data.Order.Discount,
                        gst = data.Order.gst,
                        FinalAmount = data.Order.FinalAmount,
                        OrderStatus = data.Order.OrderStatus,
                        deliveredBy = data.Order.deliveredBy,
                        UserId = data.Order.UserId,
                        AddressId = data.Order.AddressId,
                        RestId = data.Order.RestId,
                        ScheduleDeliveryAt = data.Order.ScheduleDeliveryAt,
                        orderLineItems = new List<OrderLineItem>()
                    };
                    _context.Orders.Add(order);
                }
                else
                {
                    order.OrderDate = data.Order.OrderDate;
                    order.OrderTotal = data.Order.OrderTotal;
                    order.Discount = data.Order.Discount;
                    order.gst = data.Order.gst;
                    order.FinalAmount = data.Order.FinalAmount;
                    order.OrderStatus = data.Order.OrderStatus;
                    order.deliveredBy = data.Order.deliveredBy;
                    order.UserId = data.Order.UserId;
                    order.AddressId = data.Order.AddressId;
                    order.RestId = data.Order.RestId;
                    order.ScheduleDeliveryAt = data.Order.ScheduleDeliveryAt;
                }
                _context.SaveChanges();

                // Sync OrderLineItems: Delete removed ones, update existing, add new
                var existingOLIs = order.orderLineItems.ToList();

                // Remove old items not in incoming DTO
                foreach (var existingOli in existingOLIs)
                {
                    if (!data.OrderLineItems.Any(oli => oli.OrderItemId == existingOli.OrderItemId))
                    {
                        _context.OrderLines.Remove(existingOli);
                    }
                }

                // Add or update current OrderLineItems
                foreach (var oliDto in data.OrderLineItems)
                {
                    var existingOli = existingOLIs.FirstOrDefault(x => x.OrderItemId == oliDto.OrderItemId);
                    if (existingOli == null)
                    {
                        var newOli = new OrderLineItem
                        {
                            OrderId = order.OrderId,
                            FoodItemId = oliDto.FoodItemId,
                            Quantity = oliDto.Quantity
                        };
                        _context.OrderLines.Add(newOli);
                    }
                    else
                    {
                        existingOli.FoodItemId = oliDto.FoodItemId;
                        existingOli.Quantity = oliDto.Quantity;
                        _context.OrderLines.Update(existingOli);
                    }
                }

                _context.SaveChanges();
                transaction.Commit();

                return Ok(new { result = true, message = "Order details saved successfully" });
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, new { result = false, message = ex.Message });
            }
        }

        // Get order details by orderId
        [HttpGet("{orderId}")]
        public IActionResult Get(int orderId)
        {
            var order = _context.Orders
                .Include(o => o.orderLineItems)
                .FirstOrDefault(o => o.OrderId == orderId);

            if (order == null)
                return NotFound(new { result = false, message = "Order not found" });

            var foodIds = order.orderLineItems.Select(oli => oli.FoodItemId).Distinct().ToList();
            var foods = _context.FoodItems.Where(f => foodIds.Contains(f.FoodItemId)).ToList();

            var dto = new OrderDetailsDTO
            {
                Order = new OrderDTO
                {
                    OrderId = order.OrderId,
                    OrderDate = order.OrderDate,
                    OrderTotal = order.OrderTotal,
                    Discount = order.Discount,
                    gst = order.gst,
                    FinalAmount = order.FinalAmount,
                    OrderStatus = order.OrderStatus,
                    deliveredBy = order.deliveredBy,
                    UserId = order.UserId,
                    AddressId = order.AddressId,
                    RestId = order.RestId,
                    ScheduleDeliveryAt = order.ScheduleDeliveryAt
                },
                OrderLineItems = order.orderLineItems.Select(oli => new OrderLineItemDTO
                {
                    OrderItemId = oli.OrderItemId,
                    //OrderId = oli.OrderId,
                    FoodItemId = oli.FoodItemId,
                    Quantity = oli.Quantity
                }).ToList(),
                FoodItems = foods.Select(f => new FoodItemDTO
                {
                    FoodItemId = f.FoodItemId,
                    Name = f.Name,
                    Description = f.Description,
                    Price = f.Price,
                    RestaurantId = f.RestaurantId
                }).ToList()
            };

            return Ok(dto);
        }

        // Delete order and its orderLineItems (not FoodItems)
        [HttpDelete("{orderId}")]
        public IActionResult Delete(int orderId)
        {
            var order = _context.Orders.Include(o => o.orderLineItems).FirstOrDefault(o => o.OrderId == orderId);
            if (order == null)
                return NotFound(new { result = false, message = "Order not found" });

            _context.OrderLines.RemoveRange(order.orderLineItems);
            _context.Orders.Remove(order);
            _context.SaveChanges();

            return Ok(new { result = true, message = "Order deleted successfully" });
        }
    }
}

