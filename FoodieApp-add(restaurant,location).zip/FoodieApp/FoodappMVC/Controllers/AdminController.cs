﻿using FoodieMVC.DTO;
using FoodieMVC.Infra;
using Microsoft.AspNetCore.Mvc;

namespace FoodappMVC.Controllers
{
    public class AdminController : Controller
    {
        private readonly ClientHelper clientHelper;
        public AdminController(ClientHelper client)
        {
            clientHelper = client;

        }
        [HttpGet]
        public async Task<IActionResult> ViewRestaurants()
        {
            var res = await clientHelper.GetData<GetRestaurantDTO>("Restaurant");
            return View(res.result); // assuming the API returns { result: [ ... ] }
        }

        [HttpGet]
        public IActionResult AddRestaurant()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddRestaurant(RestuarantDTO model)
        {
            var response = await clientHelper.PostData("Restaurant", model);
            if (response.IsSuccessStatusCode)
            {
                TempData["Success"] = "Restaurant added successfully!";
                return RedirectToAction("ViewRestaurants");
            }
            var error = await response.Content.ReadAsStringAsync();

            ModelState.AddModelError("", $"Something went wrong.: {error}");
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> ViewLocations()
        {
            var res = await clientHelper.GetData<GetLocationDTO>("Location"); // endpoint should match your API route
            return View(res.result); // Pass the list to the view
        }

        [HttpGet]
        public IActionResult AddLocation()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddLocation(LocationDTO model)
        {
            var response = await clientHelper.PostData("Location", model); // assuming POST /api/Location

            if (response.IsSuccessStatusCode)
            {
                TempData["Success"] = "Location added successfully!";
                return RedirectToAction("ViewLocations");
            }

            var error = await response.Content.ReadAsStringAsync();
            ModelState.AddModelError("", $"Something went wrong: {error}");
            return View(model);
        }
        [HttpGet("{orderId}")]
        public async Task<IActionResult> ViewOrder(int orderId)
        {
            var result = await clientHelper.GetData<OrderDetailsDTO>($"OrderDetails/{orderId}");
            if (result == null)
            {
                ViewBag.Error = "Order not found.";
                return View(); // Or redirect to error page
            }

            return View(result);
        }
    }
}
