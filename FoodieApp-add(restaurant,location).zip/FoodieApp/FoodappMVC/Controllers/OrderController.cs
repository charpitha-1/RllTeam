﻿using Microsoft.AspNetCore.Mvc;

namespace FoodappMVC.Controllers
{
    public class OrderController : Controller
    {
        public IActionResult Registartion()
        {

            return View();
        }
    }
}
