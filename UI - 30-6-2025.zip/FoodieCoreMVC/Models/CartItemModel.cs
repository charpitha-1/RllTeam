﻿namespace FoodieCoreMVC.Models
{
    public class CartItemModel
    {
    }
}
