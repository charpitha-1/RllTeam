﻿namespace FoodieCoreMVC.Models
{
    public class UserProfileViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
