﻿namespace FoodieApp.DTO
{
    public class LocationDTO
    {
        public int LocationId { get; set; }  // For reads; ignored on create
        public string City { get; set; }
        public string Area { get; set; }
        public string PostalCode { get; set; }
    }
}
