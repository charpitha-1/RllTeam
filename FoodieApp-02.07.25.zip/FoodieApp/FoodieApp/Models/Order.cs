﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodieApp.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }

        
        [Column(TypeName = "decimal(8,2)")]

        [Required]
        public double OrderTotal { get; set; }

        [Column(TypeName = "decimal(8,2)")]
        public double Discount { get; set; }

        [Required]
        [Column(TypeName = "decimal(8,2)")]
        public double gst { get; set; }

        [Column(TypeName = "decimal(8,2)")]
        [Required]
        public double FinalAmount { get; set; }
        
        [Required]
        public string OrderStatus { get; set; }

      
        public string deliveredBy { get; set; }

      
        public int UserId { get; set; }
        public User User { get; set; }

       
        //public string DeliveryAddress { get; set; }

        public int AddressId { get; set; }
        public Address Address { get; set; }

       
        public int RestId { get; set; }
        public Restaurant Restaurant { get; set; }
        
        public DateTime? ScheduleDeliveryAt { get; set; }
        public List<OrderLineItem> orderLineItems { get; set; }
     
    }
}
