﻿using FoodieApp.DBAccess;
using FoodieApp.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FoodieApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantController : ControllerBase
    {
        private readonly DbAccess dbAccess;

        public RestaurantController(DbAccess db)
        {
            dbAccess = db;
        }

        [HttpPost]
        public IActionResult AddRestaurant(RestaurantDTO data)
        {
            
            if (data == null)
                return BadRequest(new { result = false, message = "Invalid data" });

            bool isAdded = dbAccess.AddRestaurant(data, out string errorMessage);

            if (!isAdded)
            {
                return BadRequest(new { result = false, message = errorMessage });
            }
            return Ok(new { result = true, message = "Restaurant added successfully" });
        }

        [HttpGet]
        public IActionResult GetAllRestaurants()
        {
            var list = dbAccess.GetAllRestaurants();
            return Ok(new { result = list });
        }

        [HttpGet("{id}")]
        public IActionResult GetRestaurant(int id)
        {
            var rest = dbAccess.GetRestaurantById(id);
            if (rest == null)
                return NotFound(new { result = false, message = "Restaurant not found" });

            return Ok(new { result = true, restaurant = rest });
        }

        [HttpPut("{id}")]
        public IActionResult UpdateRestaurant(int id, RestaurantDTO data)
        {
            bool status = dbAccess.UpdateRestaurant(id, data);
            if (!status)
                return NotFound(new { result = false, message = "Restaurant not found" });

            return Ok(new { result = "Restaurant updated successfully" });
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteRestaurant(int id)
        {
            bool status = dbAccess.DeleteRestaurant(id);
            if (!status)
                return NotFound(new { result = false, message = "Restaurant not found" });

            return Ok(new { result = "Restaurant deleted successfully" });
        }
    }
}
    

